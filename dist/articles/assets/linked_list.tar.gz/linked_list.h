#ifndef _LINKED_LIST_H
#define _LINKED_LIST_H

#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>

#define element_type int64_t

struct node;
typedef struct node *list;
typedef struct node *position;

typedef struct node {
  element_type element;
  struct node *next;
} node;

int is_empty(list);
int is_last(position, list);

position find_element(element_type, list);
void delete_element(element_type, list);
position insert_element(element_type, position);

size_t delete_list(list);
list init_list(element_type);

#endif
