#include "linked_list.h"

/* return 1 if list l is empty */
int is_empty(list l) { return l->next == NULL; }

/* return 1 if position p is the last element in list */
int is_last(position p, list l) { return p->next == NULL; }

/* search element in list, return position or NULL */
position find_element(element_type element, list l) {
  position p = l->next;
  while (p != NULL && p->element != element) {
    p = p->next;
  }
  return p;
}

/* delete first occurrence of element */
void delete_element(element_type element, list l) {
  position p = l;
  while (p->next != NULL && p->next->element != element) {
    p = p->next;
  }
  if (!is_last(p, l)) {
    position tmp = p->next;
    p->next = tmp->next;
    free(tmp);
  }
}

/* insert element after position p */
position insert_element(element_type element, position p) {
  position tmp = malloc(sizeof(struct node));
  assert(tmp != NULL);
  tmp->next = p->next;
  tmp->element = element;
  p->next = tmp;
  return tmp;
}

/* delete the whole list */
size_t delete_list(list l) {
  size_t total = 1;
  position p, tmp;
  p = l->next;
  l->next = NULL;
  while (p != NULL) {
    tmp = p->next;
    free(p);
    p = tmp;
    total++;
  }
  return total;
}

/* create a list with one element */
list init_list(element_type element) {
  position cell = malloc(sizeof(struct node));
  assert(cell != NULL);
  cell->next = NULL;
  cell->element = element;
  return cell;
}