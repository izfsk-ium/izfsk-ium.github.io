﻿=== Oxygen-White Cursor Set ===

By: Erik (http://www.rw-designer.com/user/13858)

Download: http://www.rw-designer.com/cursor-set/opensuse-oxygen

Author's decription:

These are the original Oxygen-White cursors of KDE4 used in openSUSE.

For the Linux-User:
You can find them in the following folder:
'''''usr\share\icons'''''.

Enjoy, rate, download and comment.

==========

License: Creative Commons - Attribution + Share Alike

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.
* Share Alike - If you alter, transform, or build upon this work,
  you may distribute the resulting work only under the same, similar
  or a compatible license.